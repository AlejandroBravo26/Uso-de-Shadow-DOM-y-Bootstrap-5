class CalculadoraBasica extends HTMLElement {
    constructor() {
        super();
        // Creamos el Shadow DOM
        this.attachShadow({ mode: 'open' });
        this.historial = []; // Para el extra de historial

        // Construimos el contenido del Shadow DOM
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                /* Estilos propios del componente (opcional, si no usas 100% Bootstrap) */
                .card {
                    margin-top: 20px;
                }
                .form-group {
                    margin-bottom: 1rem;
                }
                #resultado {
                    font-size: 1.5rem;
                    font-weight: bold;
                    color: #007bff; /* Color Bootstrap primary */
                }
                .error-message {
                    color: #dc3545; /* Color Bootstrap danger */
                    font-weight: bold;
                }
            </style>
            <link rel="stylesheet" href="css/bootstrap.min.css">

            <div class="card shadow-sm p-4">
                <div class="card-body">
                    <h5 class="card-title text-center mb-4">Calculadora</h5>

                    <div class="form-group">
                        <label for="numero1">Número 1:</label>
                        <input type="number" class="form-control" id="numero1" placeholder="Ingrese el primer número">
                    </div>

                    <div class="form-group">
                        <label for="numero2">Número 2:</label>
                        <input type="number" class="form-control" id="numero2" placeholder="Ingrese el segundo número">
                    </div>

                    <div class="form-group">
                        <label for="operacion">Operación:</label>
                        <select class="form-select" id="operacion">
                            <option value="suma">Suma (+)</option>
                            <option value="resta">Resta (-)</option>
                            <option value="multiplicacion">Multiplicación (*)</option>
                            <option value="division">División (/)</option>
                        </select>
                    </div>

                    <button class="btn btn-primary w-100 mt-3" id="calcular">Calcular</button>

                    <div class="mt-4 text-center">
                        <p class="mb-1">Resultado:</p>
                        <div id="resultado" class="alert alert-info"></div>
                        <div id="errorMessage" class="error-message"></div>
                    </div>

                    <div id="historialContainer" class="mt-4 border-top pt-3" style="display: none;">
                        <h6 class="text-center">Historial de Operaciones</h6>
                        <ul id="historialList" class="list-group list-group-flush">
                            </ul>
                    </div>
                </div>
            </div>
        `;

        this.attachEventListeners();
    }

    attachEventListeners() {
        //Elementos del Shadow DOM
        const numero1Input = this.shadowRoot.getElementById('numero1');
        const numero2Input = this.shadowRoot.getElementById('numero2');
        const operacionSelect = this.shadowRoot.getElementById('operacion');
        const calcularButton = this.shadowRoot.getElementById('calcular');
        const resultadoDiv = this.shadowRoot.getElementById('resultado');
        const errorMessageDiv = this.shadowRoot.getElementById('errorMessage');
        const historialContainer = this.shadowRoot.getElementById('historialContainer');
        const historialList = this.shadowRoot.getElementById('historialList');

        calcularButton.addEventListener('click', () => {
            errorMessageDiv.textContent = ''; 
            resultadoDiv.textContent = ''; 
            resultadoDiv.classList.remove('alert-danger'); 

            const num1 = parseFloat(numero1Input.value);
            const num2 = parseFloat(numero2Input.value);
            const operacion = operacionSelect.value;

            // Validaciones
            if (isNaN(num1) || isNaN(num2)) {
                errorMessageDiv.textContent = 'Por favor, ingrese números válidos en ambos campos.';
                resultadoDiv.classList.add('alert-danger');
                return;
            }

            let resultado;
            let operacionSimbolo;

            switch (operacion) {
                case 'suma':
                    resultado = num1 + num2;
                    operacionSimbolo = '+';
                    break;
                case 'resta':
                    resultado = num1 - num2;
                    operacionSimbolo = '-';
                    break;
                case 'multiplicacion':
                    resultado = num1 * num2;
                    operacionSimbolo = '*';
                    break;
                case 'division':
                    if (num2 === 0) {
                        errorMessageDiv.textContent = 'Error: No se puede dividir por cero.';
                        resultadoDiv.classList.add('alert-danger');
                        return;
                    }
                    resultado = num1 / num2;
                    operacionSimbolo = '/';
                    break;
                default:
                    errorMessageDiv.textContent = 'Operación no válida.';
                    resultadoDiv.classList.add('alert-danger');
                    return;
            }

            resultadoDiv.textContent = resultado;
            resultadoDiv.classList.remove('alert-info'); 
            resultadoDiv.classList.add('alert-success'); 

            //Agrega al historial
            const operacionTexto = `${num1} ${operacionSimbolo} ${num2} = ${resultado}`;
            this.historial.push(operacionTexto);
            this.actualizarHistorial(historialList, historialContainer);

            
            this.dispatchEvent(new CustomEvent('calculo-realizado', {
                detail: {
                    numero1: num1,
                    numero2: num2,
                    operacion: operacion,
                    resultado: resultado,
                    timestamp: new Date().toISOString()
                },
                bubbles: true, 
                composed: true 
            }));
        });
    }

 
    actualizarHistorial(listElement, containerElement) {
        listElement.innerHTML = ''; 
        if (this.historial.length > 0) {
            containerElement.style.display = 'block'; 
            this.historial.forEach((item, index) => {
                const listItem = document.createElement('li');
                listItem.classList.add('list-group-item');
                listItem.textContent = `${index + 1}. ${item}`;
                listElement.appendChild(listItem);
            });
        } else {
            containerElement.style.display = 'none'; 
        }
    }
}

// Definimos el custom element
customElements.define('calculadora-basica', CalculadoraBasica);